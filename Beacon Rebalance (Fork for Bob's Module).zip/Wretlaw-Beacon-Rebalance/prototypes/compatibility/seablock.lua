require("prototypes.compatibility.bobs_modules")
--yes, if you have seablock it will just call the bob's compat a second time lol