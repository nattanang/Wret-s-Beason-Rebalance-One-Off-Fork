if mods["bobmodules"] then
	require("prototypes.compatibility.bobs_modules")
end