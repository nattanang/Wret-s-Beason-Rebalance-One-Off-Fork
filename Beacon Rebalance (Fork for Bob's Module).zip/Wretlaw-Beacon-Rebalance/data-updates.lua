--doki doki waku waku
if mods["space-age"] then
    require("prototypes.compatibility.space_age")
end